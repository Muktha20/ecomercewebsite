import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/lib/store";
import { Package, ShoppingBag, Users, IndianRupee, AlertTriangle } from "lucide-react";

export const Route = createFileRoute("/admin/")({
  component: Dashboard,
});

type Stats = {
  products: number;
  users: number;
  orders: number;
  revenue: number;
  lowStock: { id: string; name: string; stock: number }[];
  recentOrders: { id: string; email: string | null; total: number; status: string; created_at: string }[];
  recentUsers: { user_id: string; email: string | null; display_name: string | null; created_at: string }[];
};

function Dashboard() {
  const [s, setS] = useState<Stats | null>(null);

  useEffect(() => {
    (async () => {
      const [{ count: products }, { count: users }, { data: orders }, { data: low }, { data: recentOrders }, { data: recentUsers }] = await Promise.all([
        supabase.from("products").select("*", { count: "exact", head: true }),
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("orders").select("total"),
        supabase.from("products").select("id,name,stock").lte("stock", 5).order("stock", { ascending: true }).limit(5),
        supabase.from("orders").select("id,email,total,status,created_at").order("created_at", { ascending: false }).limit(5),
        supabase.from("profiles").select("user_id,email,display_name,created_at").order("created_at", { ascending: false }).limit(5),
      ]);
      const revenue = (orders ?? []).reduce((a, o) => a + Number(o.total ?? 0), 0);
      setS({
        products: products ?? 0,
        users: users ?? 0,
        orders: orders?.length ?? 0,
        revenue,
        lowStock: (low ?? []) as Stats["lowStock"],
        recentOrders: (recentOrders ?? []) as Stats["recentOrders"],
        recentUsers: (recentUsers ?? []) as Stats["recentUsers"],
      });
    })();
  }, []);

  if (!s) return <p className="text-muted-foreground text-sm">Loading…</p>;

  const cards = [
    { label: "Products", value: s.products, icon: Package, link: "/admin/products" },
    { label: "Users", value: s.users, icon: Users, link: "/admin/users" },
    { label: "Orders", value: s.orders, icon: ShoppingBag, link: "/admin/orders" },
    { label: "Revenue", value: formatPrice(s.revenue), icon: IndianRupee, link: "/admin/orders" },
  ];

  return (
    <div className="space-y-10">
      <div>
        <p className="tracking-luxe text-xs text-gold mb-2">Overview</p>
        <h1 className="font-serif text-4xl">Dashboard</h1>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <Link key={c.label} to={c.link} className="border bg-background p-6 hover:border-gold transition-colors group">
              <div className="flex items-center justify-between mb-4">
                <p className="text-xs tracking-luxe text-muted-foreground">{c.label}</p>
                <Icon className="h-4 w-4 text-gold" />
              </div>
              <p className="font-serif text-3xl group-hover:text-gold transition-colors">{c.value}</p>
            </Link>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="border bg-background p-6">
          <h2 className="font-serif text-xl mb-4">Recent Orders</h2>
          {s.recentOrders.length === 0 && <p className="text-sm text-muted-foreground">No orders yet.</p>}
          <div className="space-y-3">
            {s.recentOrders.map((o) => (
              <div key={o.id} className="flex items-center justify-between text-sm border-b pb-2 last:border-0">
                <div className="min-w-0">
                  <p className="truncate">{o.email ?? "—"}</p>
                  <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleDateString()} · {o.status}</p>
                </div>
                <span className="font-medium">{formatPrice(Number(o.total))}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="border bg-background p-6">
          <h2 className="font-serif text-xl mb-4">Recent Users</h2>
          {s.recentUsers.length === 0 && <p className="text-sm text-muted-foreground">No users yet.</p>}
          <div className="space-y-3">
            {s.recentUsers.map((u) => (
              <div key={u.user_id} className="flex items-center justify-between text-sm border-b pb-2 last:border-0">
                <div className="min-w-0">
                  <p className="truncate">{u.display_name ?? u.email ?? "—"}</p>
                  <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                </div>
                <span className="text-xs text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="border bg-background p-6">
        <h2 className="font-serif text-xl mb-4 flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-gold" /> Low Stock Alerts
        </h2>
        {s.lowStock.length === 0 ? (
          <p className="text-sm text-muted-foreground">All products are well stocked.</p>
        ) : (
          <div className="space-y-2">
            {s.lowStock.map((p) => (
              <div key={p.id} className="flex justify-between text-sm border-b pb-2 last:border-0">
                <span>{p.name}</span>
                <span className="text-destructive font-medium">{p.stock} left</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
