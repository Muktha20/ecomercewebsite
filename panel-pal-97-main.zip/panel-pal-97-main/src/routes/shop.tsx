import { createFileRoute } from "@tanstack/react-router";
import { products as staticProducts, categories, type Product } from "@/lib/products";
import { useDbProducts } from "@/lib/use-db-products";
import { ProductCard } from "@/components/site/ProductCard";
import { useMemo, useState } from "react";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { z } from "zod";

const search = z.object({ category: z.string().optional() });

export const Route = createFileRoute("/shop")({
  validateSearch: search,
  head: () => ({
    meta: [
      { title: "Shop the Edit — Videria" },
      { name: "description", content: "Browse silk gowns, leather, jewelry and more. Curated by the Videria atelier." },
      { property: "og:title", content: "Shop the Edit — Videria" },
    ],
  }),
  component: Shop,
});

function Shop() {
  const sp = Route.useSearch();
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<string>(sp.category ?? "All");
  const [price, setPrice] = useState<[number, number]>([0, 250000]);
  const [minRating, setMinRating] = useState(0);
  const [sort, setSort] = useState("featured");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const { items: dbItems } = useDbProducts();
  const all: Product[] = useMemo(() => [...dbItems, ...staticProducts], [dbItems]);

  const list = useMemo(() => {
    let r = all.filter((p) =>
      (cat === "All" || p.category === cat) &&
      p.price >= price[0] && p.price <= price[1] &&
      p.rating >= minRating &&
      (query === "" || p.name.toLowerCase().includes(query.toLowerCase()))
    );
    if (sort === "low") r = [...r].sort((a, b) => a.price - b.price);
    if (sort === "high") r = [...r].sort((a, b) => b.price - a.price);
    if (sort === "rating") r = [...r].sort((a, b) => b.rating - a.rating);
    return r;
  }, [all, cat, price, query, sort, minRating]);

  const Filters = (
    <div className="space-y-8">
      <div>
        <p className="tracking-luxe text-xs text-muted-foreground mb-4">Category</p>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`px-4 py-2 text-xs tracking-luxe border transition-colors ${cat === c ? "bg-foreground text-background border-foreground" : "border-border hover:border-foreground"}`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="tracking-luxe text-xs text-muted-foreground mb-4">Price · ₹{price[0].toLocaleString("en-IN")}–₹{price[1].toLocaleString("en-IN")}</p>
        <Slider value={price} onValueChange={(v) => setPrice([v[0], v[1]] as [number, number])} min={0} max={250000} step={5000} />
      </div>
      <div>
        <p className="tracking-luxe text-xs text-muted-foreground mb-4">Minimum rating</p>
        <div className="flex gap-2">
          {[0, 4, 4.5, 4.8].map((r) => (
            <button
              key={r}
              onClick={() => setMinRating(r)}
              className={`px-3 py-1.5 text-xs border ${minRating === r ? "bg-foreground text-background border-foreground" : "border-border hover:border-foreground"}`}
            >
              {r === 0 ? "All" : `${r}+`}
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-5 lg:px-10 py-14">
      <div className="text-center mb-12 animate-fade-up">
        <p className="tracking-luxe text-xs text-gold mb-3">The Collection</p>
        <h1 className="font-serif text-5xl lg:text-6xl">Shop the Edit</h1>
        <p className="mt-4 text-muted-foreground max-w-md mx-auto">{list.length} pieces curated for you.</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-3 mb-10">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search the Maison…" className="pl-11 h-12 rounded-none border-foreground/20" />
        </div>
        <select value={sort} onChange={(e) => setSort(e.target.value)} className="h-12 px-4 border bg-background tracking-luxe text-xs">
          <option value="featured">Featured</option>
          <option value="low">Price: Low to High</option>
          <option value="high">Price: High to Low</option>
          <option value="rating">Top Rated</option>
        </select>
        <Button variant="outlineLuxe" size="lg" className="lg:hidden" onClick={() => setFiltersOpen(true)}>
          <SlidersHorizontal className="h-4 w-4" /> Filters
        </Button>
      </div>

      <div className="grid lg:grid-cols-[260px_1fr] gap-12">
        <aside className="hidden lg:block">{Filters}</aside>

        {filtersOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-black/50" onClick={() => setFiltersOpen(false)} />
            <div className="absolute right-0 top-0 h-full w-80 bg-background p-6 overflow-y-auto animate-fade-up">
              <div className="flex justify-between items-center mb-8">
                <span className="font-serif text-2xl">Filters</span>
                <button onClick={() => setFiltersOpen(false)}><X className="h-5 w-5" /></button>
              </div>
              {Filters}
            </div>
          </div>
        )}

        {list.length === 0 ? (
          <div className="text-center py-24">
            <p className="font-serif text-2xl">No pieces match your edit.</p>
            <p className="text-muted-foreground text-sm mt-2">Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-8">
            {list.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>
        )}
      </div>
    </div>
  );
}
