import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { formatPrice } from "@/lib/store";
import { Pencil, Trash2, Plus, Search } from "lucide-react";

export const Route = createFileRoute("/admin/products")({
  component: ProductsPage,
});

type Row = {
  id: string;
  name: string;
  price: number;
  offer_price: number | null;
  image: string;
  category: string;
  brand: string | null;
  stock: number;
  rating: number;
  description: string;
  badge: string | null;
};

const empty = { name: "", price: "", offer_price: "", image: "", category: "", brand: "", stock: "100", rating: "4.5", description: "", badge: "" };

const PAGE_SIZE = 8;

function ProductsPage() {
  const [items, setItems] = useState<Row[]>([]);
  const [cats, setCats] = useState<{ name: string }[]>([]);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState<Row | null>(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  const refresh = async () => {
    const { data } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    setItems((data ?? []) as Row[]);
  };

  useEffect(() => {
    refresh();
    supabase.from("categories").select("name").order("name").then(({ data }) => setCats(data ?? []));
  }, []);

  const filtered = useMemo(() => {
    return items.filter((p) => {
      if (filter !== "all" && p.category !== filter) return false;
      if (q && !p.name.toLowerCase().includes(q.toLowerCase()) && !(p.brand?.toLowerCase().includes(q.toLowerCase()))) return false;
      return true;
    });
  }, [items, q, filter]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const openNew = () => {
    setEditing(null);
    setForm({ ...empty, category: cats[0]?.name ?? "Apparel" });
    setOpen(true);
  };

  const openEdit = (p: Row) => {
    setEditing(p);
    setForm({
      name: p.name,
      price: String(p.price),
      offer_price: p.offer_price != null ? String(p.offer_price) : "",
      image: p.image,
      category: p.category,
      brand: p.brand ?? "",
      stock: String(p.stock),
      rating: String(p.rating),
      description: p.description,
      badge: p.badge ?? "",
    });
    setOpen(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const payload = {
      name: form.name,
      price: Number(form.price),
      offer_price: form.offer_price ? Number(form.offer_price) : null,
      image: form.image,
      category: form.category,
      brand: form.brand || null,
      stock: Number(form.stock),
      rating: Number(form.rating),
      description: form.description,
      badge: form.badge || null,
    };
    const { error } = editing
      ? await supabase.from("products").update(payload).eq("id", editing.id)
      : await supabase.from("products").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(editing ? "Product updated." : "Product added.");
    setOpen(false);
    refresh();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed.");
    refresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="tracking-luxe text-xs text-gold mb-2">Catalog</p>
          <h1 className="font-serif text-4xl">Products</h1>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button variant="luxe" onClick={openNew}><Plus className="h-4 w-4 mr-2" /> Add Product</Button>
          </DialogTrigger>
          <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-serif text-2xl">{editing ? "Edit Product" : "Add Product"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={submit} className="space-y-3">
              <Input required placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Input required type="number" min="0" placeholder="Price (₹)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
                <Input type="number" min="0" placeholder="Offer price (₹)" value={form.offer_price} onChange={(e) => setForm({ ...form, offer_price: e.target.value })} />
              </div>
              <Input required placeholder="Image URL" value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
                  <SelectContent>
                    {cats.map((c) => <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Input placeholder="Brand" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <Input required type="number" min="0" placeholder="Stock" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
                <Input type="number" min="0" max="5" step="0.1" placeholder="Rating" value={form.rating} onChange={(e) => setForm({ ...form, rating: e.target.value })} />
                <Input placeholder="Badge" value={form.badge} onChange={(e) => setForm({ ...form, badge: e.target.value })} />
              </div>
              <Textarea placeholder="Description" rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button type="submit" variant="luxe" disabled={saving}>{saving ? "Saving…" : editing ? "Save Changes" : "Add Product"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search by name or brand" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} className="pl-9" />
        </div>
        <Select value={filter} onValueChange={(v) => { setFilter(v); setPage(1); }}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {cats.map((c) => <SelectItem key={c.name} value={c.name}>{c.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="border bg-background overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-left tracking-luxe text-xs">
            <tr>
              <th className="p-3">Product</th>
              <th className="p-3">Category</th>
              <th className="p-3">Price</th>
              <th className="p-3">Stock</th>
              <th className="p-3 w-24"></th>
            </tr>
          </thead>
          <tbody>
            {paged.length === 0 && (
              <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No products.</td></tr>
            )}
            {paged.map((p) => (
              <tr key={p.id} className="border-t hover:bg-muted/20">
                <td className="p-3">
                  <div className="flex gap-3 items-center">
                    <img src={p.image} alt={p.name} className="h-12 w-12 object-cover" />
                    <div className="min-w-0">
                      <p className="font-medium truncate max-w-[260px]">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.brand ?? "—"}</p>
                    </div>
                  </div>
                </td>
                <td className="p-3 text-muted-foreground">{p.category}</td>
                <td className="p-3">
                  <span>{formatPrice(p.offer_price ?? p.price)}</span>
                  {p.offer_price != null && <span className="ml-2 text-xs text-muted-foreground line-through">{formatPrice(p.price)}</span>}
                </td>
                <td className="p-3">
                  <span className={p.stock <= 5 ? "text-destructive font-medium" : ""}>{p.stock}</span>
                </td>
                <td className="p-3 text-right">
                  <div className="flex gap-1 justify-end">
                    <button onClick={() => openEdit(p)} className="p-2 hover:text-gold" aria-label="Edit"><Pencil className="h-4 w-4" /></button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button className="p-2 hover:text-destructive" aria-label="Delete"><Trash2 className="h-4 w-4" /></button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete this product?</AlertDialogTitle>
                          <AlertDialogDescription>This cannot be undone. "{p.name}" will be removed from the catalog.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => remove(p.id)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between text-sm">
        <p className="text-muted-foreground">Page {page} of {pages} · {filtered.length} products</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</Button>
          <Button variant="outline" size="sm" disabled={page >= pages} onClick={() => setPage(page + 1)}>Next</Button>
        </div>
      </div>
    </div>
  );
}
