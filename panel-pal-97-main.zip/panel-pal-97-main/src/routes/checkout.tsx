import { createFileRoute, Link } from "@tanstack/react-router";
import { useShop, formatPrice } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/checkout")({
  head: () => ({ meta: [{ title: "Checkout — Videria" }, { name: "description", content: "Complete your order." }] }),
  component: Checkout,
});

function Checkout() {
  const { cart, subtotal, discount, total, applyCoupon, coupon, clear } = useShop();
  const [code, setCode] = useState("");
  const [done, setDone] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [form, setForm] = useState({ email: "", name: "", lastname: "", address: "", city: "", postal: "", country: "" });

  const onPay = async (e: React.FormEvent) => {
    e.preventDefault();
    const { data: s } = await supabase.auth.getSession();
    const uid = s.session?.user.id;
    if (!uid) {
      toast.error("Please sign in to place an order.");
      return;
    }
    const items = cart.map((c) => ({ id: c.product.id, name: c.product.name, qty: c.qty, price: c.product.price, image: c.product.image }));
    const { data, error } = await supabase.from("orders").insert({
      user_id: uid,
      email: form.email || s.session?.user.email,
      items,
      subtotal: subtotal(),
      total: total(),
      status: "pending",
      shipping_address: { name: `${form.name} ${form.lastname}`.trim(), address: form.address, city: form.city, postal: form.postal, country: form.country },
    }).select("id").single();
    if (error) return toast.error(error.message);
    setOrderId(data.id.slice(0, 8).toUpperCase());
    setDone(true);
    setTimeout(() => clear(), 100);
  };

  if (done) {
    return (
      <div className="max-w-2xl mx-auto px-5 py-24 text-center">
        <CheckCircle2 className="h-16 w-16 text-gold mx-auto mb-6" />
        <h1 className="font-serif text-5xl">Thank you.</h1>
        <p className="mt-4 text-muted-foreground">Your order <span className="text-gold font-medium">{orderId}</span> has been received. A confirmation has been sent to your email.</p>
        <div className="flex gap-3 justify-center mt-10">
          <Button variant="luxe" asChild><Link to="/orders">Track Order</Link></Button>
          <Button variant="outlineLuxe" asChild><Link to="/shop">Continue Shopping</Link></Button>
        </div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-5 py-32 text-center">
        <h1 className="font-serif text-4xl">Your bag is empty</h1>
        <Button variant="luxe" className="mt-8" asChild><Link to="/shop">Begin shopping</Link></Button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-5 lg:px-10 py-14">
      <h1 className="font-serif text-5xl mb-12 text-center">Checkout</h1>
      <form onSubmit={onPay} className="grid lg:grid-cols-[1fr_400px] gap-12">
        <div className="space-y-10">
          <section>
            <h2 className="tracking-luxe text-xs text-gold mb-5">Contact</h2>
            <Input required type="email" placeholder="Email address" className="h-12 rounded-none" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </section>
          <section className="space-y-3">
            <h2 className="tracking-luxe text-xs text-gold mb-5">Shipping</h2>
            <div className="grid grid-cols-2 gap-3">
              <Input required placeholder="First name" className="h-12 rounded-none" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <Input required placeholder="Last name" className="h-12 rounded-none" value={form.lastname} onChange={(e) => setForm({ ...form, lastname: e.target.value })} />
            </div>
            <Input required placeholder="Address" className="h-12 rounded-none" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <div className="grid grid-cols-3 gap-3">
              <Input required placeholder="City" className="h-12 rounded-none" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              <Input required placeholder="Postal code" className="h-12 rounded-none" value={form.postal} onChange={(e) => setForm({ ...form, postal: e.target.value })} />
              <Input required placeholder="Country" className="h-12 rounded-none" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
            </div>
          </section>
          <section className="space-y-3">
            <h2 className="tracking-luxe text-xs text-gold mb-5">Payment <span className="text-muted-foreground">· Demo</span></h2>
            <Input required placeholder="Card number" defaultValue="4242 4242 4242 4242" className="h-12 rounded-none" />
            <div className="grid grid-cols-2 gap-3">
              <Input required placeholder="MM / YY" defaultValue="12 / 28" className="h-12 rounded-none" />
              <Input required placeholder="CVC" defaultValue="123" className="h-12 rounded-none" />
            </div>
          </section>
        </div>

        <aside className="lg:sticky lg:top-28 lg:self-start bg-card border p-7 space-y-5">
          <h2 className="font-serif text-2xl">Order summary</h2>
          <div className="space-y-4 max-h-72 overflow-y-auto">
            {cart.map((c) => (
              <div key={c.product.id} className="flex gap-3">
                <div className="h-16 w-14 bg-muted overflow-hidden flex-shrink-0">
                  <img src={c.product.image} alt={c.product.name} className="h-full w-full object-cover" />
                </div>
                <div className="flex-1 text-sm">
                  <p className="font-serif text-base">{c.product.name}</p>
                  <p className="text-muted-foreground text-xs">Qty {c.qty}</p>
                </div>
                <span className="text-sm font-medium">{formatPrice(c.product.price * c.qty)}</span>
              </div>
            ))}
          </div>

          <div className="flex gap-2 pt-3 border-t">
            <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Promo code" className="rounded-none" />
            <Button type="button" variant="outlineLuxe" onClick={() => {
              if (applyCoupon(code)) toast.success("Coupon applied");
              else toast.error("Invalid coupon. Try LUXE10");
            }}>Apply</Button>
          </div>
          {coupon && <p className="text-xs text-gold tracking-luxe">{coupon} applied</p>}

          <div className="space-y-2 pt-3 border-t text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatPrice(subtotal())}</span></div>
            {discount() > 0 && <div className="flex justify-between text-gold"><span>Discount</span><span>−{formatPrice(discount())}</span></div>}
            <div className="flex justify-between"><span className="text-muted-foreground">Shipping</span><span>Complimentary</span></div>
            <div className="flex justify-between text-lg font-medium pt-3 border-t"><span>Total</span><span>{formatPrice(total())}</span></div>
          </div>

          <Button variant="gold" size="xl" className="w-full" type="submit">Pay {formatPrice(total())}</Button>
          <p className="text-[10px] text-muted-foreground text-center">Demo checkout · No real charge</p>
        </aside>
      </form>
    </div>
  );
}
