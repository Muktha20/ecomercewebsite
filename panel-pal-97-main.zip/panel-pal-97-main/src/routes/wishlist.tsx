import { createFileRoute, Link } from "@tanstack/react-router";
import { useShop } from "@/lib/store";
import { products } from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/wishlist")({
  head: () => ({ meta: [{ title: "Wishlist — Videria" }, { name: "description", content: "Pieces you love." }] }),
  component: Wishlist,
});

function Wishlist() {
  const wishlist = useShop((s) => s.wishlist);
  const items = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-5 lg:px-10 py-14">
      <div className="text-center mb-14">
        <p className="tracking-luxe text-xs text-gold mb-3">Saved</p>
        <h1 className="font-serif text-5xl">Wishlist</h1>
      </div>
      {items.length === 0 ? (
        <div className="text-center py-24">
          <p className="font-serif text-2xl">Your wishlist is empty.</p>
          <Button variant="luxe" className="mt-8" asChild><Link to="/shop">Discover pieces</Link></Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {items.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      )}
    </div>
  );
}
