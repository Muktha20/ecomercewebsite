import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/account")({
  head: () => ({ meta: [{ title: "Account — Videria" }, { name: "description", content: "Sign in or create your account." }] }),
  component: Account,
});

function Account() {
  const [tab, setTab] = useState("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState<{ email?: string } | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => sub.subscription.unsubscribe();
  }, []);

  const signIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Welcome back.");
    navigate({ to: "/" });
  };

  const signUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: `${window.location.origin}/`, data: { name } },
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Account created. Check your email to confirm.");
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out.");
  };

  if (user) {
    return (
      <div className="max-w-md mx-auto px-5 py-20 text-center">
        <p className="tracking-luxe text-xs text-gold mb-3">Maison</p>
        <h1 className="font-serif text-5xl mb-3">Welcome</h1>
        <p className="text-muted-foreground mb-8">{user.email}</p>
        <Button variant="luxe" size="xl" onClick={signOut}>Sign Out</Button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-5 py-20">
      <div className="text-center mb-10">
        <p className="tracking-luxe text-xs text-gold mb-3">Maison</p>
        <h1 className="font-serif text-5xl">Your Account</h1>
      </div>
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-2 w-full rounded-none h-12">
          <TabsTrigger value="signin" className="rounded-none tracking-luxe text-xs">Sign In</TabsTrigger>
          <TabsTrigger value="signup" className="rounded-none tracking-luxe text-xs">Register</TabsTrigger>
        </TabsList>
        <TabsContent value="signin" className="space-y-3 pt-6">
          <form className="space-y-3" onSubmit={signIn}>
            <Input type="email" required placeholder="Email" className="h-12 rounded-none" value={email} onChange={(e) => setEmail(e.target.value)} />
            <Input type="password" required placeholder="Password" className="h-12 rounded-none" value={password} onChange={(e) => setPassword(e.target.value)} />
            <Button variant="luxe" size="xl" className="w-full" type="submit" disabled={loading}>{loading ? "…" : "Sign In"}</Button>
          </form>
        </TabsContent>
        <TabsContent value="signup" className="space-y-3 pt-6">
          <form className="space-y-3" onSubmit={signUp}>
            <Input required placeholder="Full name" className="h-12 rounded-none" value={name} onChange={(e) => setName(e.target.value)} />
            <Input type="email" required placeholder="Email" className="h-12 rounded-none" value={email} onChange={(e) => setEmail(e.target.value)} />
            <Input type="password" required placeholder="Password (min 6)" minLength={6} className="h-12 rounded-none" value={password} onChange={(e) => setPassword(e.target.value)} />
            <Button variant="luxe" size="xl" className="w-full" type="submit" disabled={loading}>{loading ? "…" : "Create Account"}</Button>
          </form>
        </TabsContent>
      </Tabs>
    </div>
  );
}
