import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mail, MapPin, Phone } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import { z } from "zod";

const schema = z.object({
  name: z.string().trim().min(1).max(80),
  email: z.string().trim().email().max(160),
  message: z.string().trim().min(5).max(1000),
});

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Videria" },
      { name: "description", content: "Speak with the maison. We respond within one business day." },
      { property: "og:title", content: "Contact — Videria" },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse(form);
    if (!r.success) { toast.error(r.error.issues[0]?.message ?? "Invalid"); return; }
    toast.success("Thank you. We'll be in touch soon.");
    setForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="max-w-6xl mx-auto px-5 lg:px-10 py-20">
      <div className="text-center mb-16">
        <p className="tracking-luxe text-xs text-gold mb-3">Help & Support</p>
        <h1 className="font-serif text-5xl lg:text-6xl">Speak with us.</h1>
        <p className="mt-4 text-muted-foreground max-w-md mx-auto">We respond, attentively, within one business day.</p>
      </div>

      <div className="mb-16 p-8 border border-gold/30 bg-gold/5 max-w-2xl mx-auto text-center">
        <p className="tracking-luxe text-xs text-gold mb-3">Customer Care · Help</p>
        <h2 className="font-serif text-3xl mb-4">Muktha N</h2>
        <p className="text-sm text-muted-foreground mb-1">ACS College of Engineering</p>
        <p className="text-sm">
          <a href="tel:7411069946" className="hover:text-gold transition-colors">+91 74110 69946</a>
        </p>
        <p className="text-sm">
          <a href="mailto:muktha3423@gmail.com" className="hover:text-gold transition-colors">muktha3423@gmail.com</a>
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-16">
        <div className="space-y-8">
          <div className="flex gap-4"><MapPin className="h-5 w-5 text-gold mt-1" /><div><p className="font-serif text-xl">Atelier</p><p className="text-muted-foreground text-sm">ACS College of Engineering, Bengaluru</p></div></div>
          <div className="flex gap-4"><Mail className="h-5 w-5 text-gold mt-1" /><div><p className="font-serif text-xl">Email</p><p className="text-muted-foreground text-sm">muktha3423@gmail.com</p></div></div>
          <div className="flex gap-4"><Phone className="h-5 w-5 text-gold mt-1" /><div><p className="font-serif text-xl">Phone</p><p className="text-muted-foreground text-sm">+91 74110 69946</p></div></div>
        </div>
        <form onSubmit={onSubmit} className="space-y-3">
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Name" className="h-12 rounded-none" maxLength={80} />
          <Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="Email" type="email" className="h-12 rounded-none" maxLength={160} />
          <Textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Your message" rows={6} className="rounded-none" maxLength={1000} />
          <Button variant="luxe" size="xl" type="submit" className="w-full">Send Message</Button>
        </form>
      </div>
    </div>
  );
}
