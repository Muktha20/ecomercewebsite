import { createFileRoute, Link } from "@tanstack/react-router";
import { products } from "@/lib/products";
import { ProductCard } from "@/components/site/ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Truck, ShieldCheck, Gift } from "lucide-react";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Videria — Quietly Crafted Luxury" },
      { name: "description", content: "Considered fashion, jewelry and accessories from Italian and French ateliers." },
      { property: "og:image", content: hero },
    ],
  }),
  component: Home,
});

function Home() {
  const featured = products.slice(0, 4);
  const trending = products.slice(2, 8);
  const cats = [
    { name: "Apparel", img: products[0].image },
    { name: "Bags", img: products[2].image },
    { name: "Jewelry", img: products[1].image },
    { name: "Footwear", img: products[3].image },
  ];

  return (
    <div className="-mt-16 lg:-mt-20">
      {/* Hero */}
      <section className="relative h-[100svh] min-h-[640px] overflow-hidden">
        <img
          src={hero}
          alt="Videria hero"
          width={1920}
          height={1080}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/70" />
        <div className="absolute inset-0 flex items-end lg:items-center">
          <div className="max-w-7xl mx-auto px-5 lg:px-10 w-full pb-20 lg:pb-0">
            <div className="max-w-2xl text-background animate-fade-up">
              <p className="tracking-luxe text-xs text-gold mb-5">Autumn / Winter Collection</p>
              <h1 className="font-serif text-5xl sm:text-7xl lg:text-8xl leading-[0.95]">
                Quietly<br />
                <em className="text-gold not-italic">crafted</em><br />
                luxury.
              </h1>
              <p className="mt-6 text-base text-background/80 max-w-md leading-relaxed">
                Pieces that whisper, never shout. Hand-finished in small ateliers across Italy and France.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <Button variant="gold" size="xl" asChild>
                  <Link to="/shop">Shop the Edit <ArrowRight className="h-4 w-4" /></Link>
                </Button>
                <Button size="xl" asChild className="bg-transparent border border-background text-background hover:bg-background hover:text-foreground rounded-none tracking-luxe">
                  <Link to="/about">Our Story</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="border-b">
        <div className="max-w-7xl mx-auto px-5 lg:px-10 py-6 grid grid-cols-2 lg:grid-cols-4 gap-6 text-xs tracking-luxe text-muted-foreground">
          <div className="flex items-center gap-3"><Truck className="h-4 w-4 text-gold" /> Complimentary Worldwide Delivery</div>
          <div className="flex items-center gap-3"><ShieldCheck className="h-4 w-4 text-gold" /> Lifetime Authenticity</div>
          <div className="flex items-center gap-3"><Gift className="h-4 w-4 text-gold" /> Maison Gift Wrapping</div>
          <div className="flex items-center gap-3"><Sparkles className="h-4 w-4 text-gold" /> Hand-finished in Italy</div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-5 lg:px-10 py-24">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="tracking-luxe text-xs text-gold mb-3">Explore</p>
            <h2 className="font-serif text-4xl lg:text-5xl">By Category</h2>
          </div>
          <Link to="/shop" className="story-link text-sm hidden sm:block">View All</Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-6">
          {cats.map((c, i) => (
            <Link
              key={c.name}
              to="/shop"
              search={{ category: c.name }}
              className="group relative aspect-[3/4] overflow-hidden bg-muted animate-fade-up"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <img src={c.img} alt={c.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5 text-background">
                <p className="font-serif text-2xl">{c.name}</p>
                <p className="text-[10px] tracking-luxe opacity-80 mt-1">Discover →</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="max-w-7xl mx-auto px-5 lg:px-10 py-12">
        <div className="text-center mb-14">
          <p className="tracking-luxe text-xs text-gold mb-3">The Edit</p>
          <h2 className="font-serif text-4xl lg:text-5xl">Featured Pieces</h2>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {featured.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      </section>

      {/* Editorial banner */}
      <section className="relative my-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-dark" />
        <div className="absolute -top-20 -right-20 h-96 w-96 rounded-full bg-gold/20 blur-3xl animate-blob" />
        <div className="absolute -bottom-20 -left-20 h-96 w-96 rounded-full bg-gold/10 blur-3xl animate-blob" style={{ animationDelay: "5s" }} />
        <div className="relative max-w-5xl mx-auto px-5 lg:px-10 py-28 text-center text-background">
          <p className="tracking-luxe text-xs text-gold mb-5">Maison Exclusive</p>
          <h2 className="font-serif text-4xl lg:text-6xl leading-tight">
            Enjoy <em className="text-gold not-italic">10% off</em><br />your first order
          </h2>
          <p className="mt-6 text-background/70 max-w-md mx-auto">Use code <span className="text-gold font-medium tracking-widest">LUXE10</span> at checkout.</p>
          <Button variant="gold" size="xl" className="mt-9" asChild>
            <Link to="/shop">Begin Shopping</Link>
          </Button>
        </div>
      </section>

      {/* Trending */}
      <section className="max-w-7xl mx-auto px-5 lg:px-10 py-12">
        <div className="text-center mb-14">
          <p className="tracking-luxe text-xs text-gold mb-3">Coveted</p>
          <h2 className="font-serif text-4xl lg:text-5xl">Trending Now</h2>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-8">
          {trending.slice(0, 6).map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      </section>

      {/* Testimonials */}
      <section className="max-w-7xl mx-auto px-5 lg:px-10 py-24">
        <div className="text-center mb-14">
          <p className="tracking-luxe text-xs text-gold mb-3">Whispers</p>
          <h2 className="font-serif text-4xl lg:text-5xl">From Our Patrons</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { q: "Every detail considered. The silk gown arrived wrapped like a love letter.", a: "— Eloise R., Paris" },
            { q: "I've never felt more myself than in this coat. Pure quiet confidence.", a: "— Mira K., Milan" },
            { q: "The watch is a heirloom in waiting. Truly exceptional craftsmanship.", a: "— Theo A., London" },
          ].map((t, i) => (
            <figure key={i} className="bg-card border p-8 hover-lift">
              <p className="font-serif text-xl leading-relaxed">"{t.q}"</p>
              <figcaption className="tracking-luxe text-xs text-muted-foreground mt-6">{t.a}</figcaption>
            </figure>
          ))}
        </div>
      </section>
    </div>
  );
}
