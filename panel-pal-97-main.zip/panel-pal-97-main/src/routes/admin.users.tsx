import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Search, Trash2, Ban, CheckCircle2 } from "lucide-react";

export const Route = createFileRoute("/admin/users")({
  component: UsersPage,
});

type Row = {
  user_id: string;
  email: string | null;
  display_name: string | null;
  blocked: boolean;
  created_at: string;
};

function UsersPage() {
  const [items, setItems] = useState<Row[]>([]);
  const [q, setQ] = useState("");

  const refresh = async () => {
    const { data } = await supabase.from("profiles").select("user_id,email,display_name,blocked,created_at").order("created_at", { ascending: false });
    setItems((data ?? []) as Row[]);
  };
  useEffect(() => { refresh(); }, []);

  const toggleBlock = async (u: Row) => {
    const { error } = await supabase.from("profiles").update({ blocked: !u.blocked }).eq("user_id", u.user_id);
    if (error) return toast.error(error.message);
    toast.success(u.blocked ? "User unblocked." : "User blocked.");
    refresh();
  };

  const remove = async (u: Row) => {
    const { error } = await supabase.from("profiles").delete().eq("user_id", u.user_id);
    if (error) return toast.error(error.message);
    toast.success("Profile removed.");
    refresh();
  };

  const filtered = items.filter((u) =>
    !q || u.email?.toLowerCase().includes(q.toLowerCase()) || u.display_name?.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <p className="tracking-luxe text-xs text-gold mb-2">People</p>
        <h1 className="font-serif text-4xl">Users</h1>
      </div>

      <div className="relative max-w-md">
        <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="Search email or name" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
      </div>

      <div className="border bg-background overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-left tracking-luxe text-xs">
            <tr>
              <th className="p-3">Name</th>
              <th className="p-3">Email</th>
              <th className="p-3">Joined</th>
              <th className="p-3">Status</th>
              <th className="p-3 w-32"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No users.</td></tr>
            )}
            {filtered.map((u) => (
              <tr key={u.user_id} className="border-t hover:bg-muted/20">
                <td className="p-3">{u.display_name ?? "—"}</td>
                <td className="p-3 text-muted-foreground">{u.email ?? "—"}</td>
                <td className="p-3 text-muted-foreground">{new Date(u.created_at).toLocaleDateString()}</td>
                <td className="p-3">
                  {u.blocked
                    ? <span className="text-destructive text-xs tracking-luxe">BLOCKED</span>
                    : <span className="text-green-600 text-xs tracking-luxe">ACTIVE</span>}
                </td>
                <td className="p-3 text-right">
                  <div className="flex gap-1 justify-end">
                    <button onClick={() => toggleBlock(u)} className="p-2 hover:text-gold" aria-label={u.blocked ? "Unblock" : "Block"}>
                      {u.blocked ? <CheckCircle2 className="h-4 w-4" /> : <Ban className="h-4 w-4" />}
                    </button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <button className="p-2 hover:text-destructive" aria-label="Delete"><Trash2 className="h-4 w-4" /></button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Remove this profile?</AlertDialogTitle>
                          <AlertDialogDescription>This removes the profile record. The auth account itself can only be removed from the backend.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => remove(u)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
