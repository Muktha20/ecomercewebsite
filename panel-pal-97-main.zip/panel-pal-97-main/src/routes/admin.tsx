import { createFileRoute, Link, Outlet, useRouterState, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Package, FolderTree, ShoppingBag, Users, LogOut, Menu, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — Videria" }] }),
  component: AdminLayout,
});

const nav = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/products", label: "Products", icon: Package },
  { to: "/admin/categories", label: "Categories", icon: FolderTree },
  { to: "/admin/orders", label: "Orders", icon: ShoppingBag },
  { to: "/admin/users", label: "Users", icon: Users },
];

function AdminLayout() {
  const [userId, setUserId] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    const loadRole = async (u: { id: string; email?: string } | null) => {
      if (cancelled) return;
      setUserId(u?.id ?? null);
      setEmail(u?.email ?? null);
      if (!u) { setIsAdmin(false); setChecking(false); return; }
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", u.id).eq("role", "admin").maybeSingle();
      if (cancelled) return;
      setIsAdmin(!!data);
      setChecking(false);
    };
    // Listener first — but DEFER any supabase calls to avoid deadlock
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setTimeout(() => loadRole(session?.user ?? null), 0);
    });
    // Then initial session
    supabase.auth.getSession().then(({ data }) => loadRole(data.session?.user ?? null));
    return () => { cancelled = true; sub.subscription.unsubscribe(); };
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    toast.success("Signed out.");
    navigate({ to: "/account" });
  };

  if (checking) return <div className="max-w-md mx-auto px-5 py-32 text-center text-muted-foreground">Checking access…</div>;

  if (!userId) {
    return (
      <div className="max-w-md mx-auto px-5 py-24 text-center">
        <p className="tracking-luxe text-xs text-gold mb-3">Admin</p>
        <h1 className="font-serif text-4xl mb-4">Sign in required</h1>
        <p className="text-muted-foreground mb-8 text-sm">Please sign in with an admin account to manage the store.</p>
        <Link to="/account"><Button variant="luxe" size="xl">Go to Sign In</Button></Link>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="max-w-lg mx-auto px-5 py-24 text-center">
        <p className="tracking-luxe text-xs text-gold mb-3">Admin</p>
        <h1 className="font-serif text-4xl mb-4">Not authorized</h1>
        <p className="text-muted-foreground text-sm">
          Your account is not an admin. To grant admin access, add a row in the <code>user_roles</code> table for your user with role <code>admin</code>.
        </p>
        <p className="text-xs text-muted-foreground mt-6 break-all">User ID: {userId}</p>
        <Button variant="outlineLuxe" className="mt-8" onClick={signOut}>Sign Out</Button>
      </div>
    );
  }

  const isActive = (to: string, exact?: boolean) => exact ? path === to : path === to || path.startsWith(to + "/");

  return (
    <div className="min-h-[calc(100vh-5rem)] flex bg-muted/20">
      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-background border-r transform transition-transform ${open ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 pt-16 lg:pt-0`}>
        <div className="p-6 border-b">
          <p className="tracking-luxe text-[10px] text-gold">Videria</p>
          <p className="font-serif text-xl">Admin Panel</p>
        </div>
        <nav className="p-3 space-y-1">
          {nav.map((n) => {
            const Icon = n.icon;
            const active = isActive(n.to, n.exact);
            return (
              <Link
                key={n.to}
                to={n.to}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 px-4 py-2.5 text-sm tracking-wide transition-colors ${active ? "bg-foreground text-background" : "hover:bg-muted text-foreground/70 hover:text-foreground"}`}
              >
                <Icon className="h-4 w-4" />
                {n.label}
              </Link>
            );
          })}
        </nav>
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t bg-background">
          <p className="text-xs text-muted-foreground truncate mb-2">{email}</p>
          <button onClick={signOut} className="flex items-center gap-2 text-xs text-muted-foreground hover:text-destructive">
            <LogOut className="h-3.5 w-3.5" /> Sign Out
          </button>
        </div>
      </aside>

      {open && <div className="fixed inset-0 z-30 bg-black/40 lg:hidden" onClick={() => setOpen(false)} />}

      {/* Main */}
      <div className="flex-1 min-w-0">
        <header className="lg:hidden sticky top-16 z-20 bg-background/95 backdrop-blur border-b flex items-center justify-between px-4 h-12">
          <button onClick={() => setOpen(!open)} aria-label="Menu">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
          <p className="font-serif">Admin</p>
          <div className="w-5" />
        </header>
        <main className="p-6 lg:p-10 max-w-7xl">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
