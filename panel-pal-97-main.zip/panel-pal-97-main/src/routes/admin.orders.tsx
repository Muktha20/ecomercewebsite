import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { formatPrice } from "@/lib/store";
import { Eye } from "lucide-react";

export const Route = createFileRoute("/admin/orders")({
  component: OrdersPage,
});

const STATUSES = ["pending", "processing", "shipped", "delivered", "cancelled"];

type Item = { name?: string; qty?: number; price?: number; image?: string };
type Order = {
  id: string;
  user_id: string;
  email: string | null;
  items: Item[];
  total: number;
  subtotal: number;
  status: string;
  shipping_address: Record<string, string> | null;
  created_at: string;
};

function OrdersPage() {
  const [items, setItems] = useState<Order[]>([]);
  const [filter, setFilter] = useState("all");

  const refresh = async () => {
    const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
    setItems((data ?? []) as unknown as Order[]);
  };
  useEffect(() => { refresh(); }, []);

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${status}.`);
    refresh();
  };

  const filtered = filter === "all" ? items : items.filter((o) => o.status === filter);

  const statusColor = (s: string) =>
    s === "delivered" ? "text-green-600" :
    s === "cancelled" ? "text-destructive" :
    s === "shipped" ? "text-blue-600" :
    s === "processing" ? "text-gold" : "text-muted-foreground";

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end flex-wrap gap-4">
        <div>
          <p className="tracking-luxe text-xs text-gold mb-2">Fulfillment</p>
          <h1 className="font-serif text-4xl">Orders</h1>
        </div>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="border bg-background overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 text-left tracking-luxe text-xs">
            <tr>
              <th className="p-3">Order</th>
              <th className="p-3">Customer</th>
              <th className="p-3">Date</th>
              <th className="p-3">Total</th>
              <th className="p-3">Status</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">No orders.</td></tr>
            )}
            {filtered.map((o) => (
              <tr key={o.id} className="border-t hover:bg-muted/20">
                <td className="p-3 font-mono text-xs">{o.id.slice(0, 8)}</td>
                <td className="p-3">{o.email ?? "—"}</td>
                <td className="p-3 text-muted-foreground">{new Date(o.created_at).toLocaleDateString()}</td>
                <td className="p-3 font-medium">{formatPrice(Number(o.total))}</td>
                <td className="p-3">
                  <Select value={o.status} onValueChange={(v) => updateStatus(o.id, v)}>
                    <SelectTrigger className={`w-36 h-8 ${statusColor(o.status)}`}><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </td>
                <td className="p-3">
                  <Dialog>
                    <DialogTrigger asChild>
                      <button className="p-2 hover:text-gold" aria-label="View"><Eye className="h-4 w-4" /></button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle className="font-serif text-2xl">Order #{o.id.slice(0, 8)}</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 text-sm">
                        <div>
                          <p className="tracking-luxe text-xs text-gold mb-1">Customer</p>
                          <p>{o.email}</p>
                        </div>
                        {o.shipping_address && (
                          <div>
                            <p className="tracking-luxe text-xs text-gold mb-1">Shipping</p>
                            <p>{o.shipping_address.name}</p>
                            <p>{o.shipping_address.address}</p>
                            <p>{o.shipping_address.city}, {o.shipping_address.postal} · {o.shipping_address.country}</p>
                          </div>
                        )}
                        <div>
                          <p className="tracking-luxe text-xs text-gold mb-2">Items</p>
                          <div className="space-y-2">
                            {(o.items ?? []).map((it, i) => (
                              <div key={i} className="flex justify-between border-b pb-2">
                                <span>{it.name} × {it.qty}</span>
                                <span>{formatPrice(Number(it.price ?? 0) * Number(it.qty ?? 1))}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="flex justify-between pt-2 border-t font-medium text-base">
                          <span>Total</span>
                          <span>{formatPrice(Number(o.total))}</span>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
