import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story — Videria" },
      { name: "description", content: "Videria is a small atelier collective producing quietly crafted luxury since 2019." },
      { property: "og:title", content: "Our Story — Videria" },
      { property: "og:description", content: "A maison of measured intention, founded in Florence." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <div>
      <section className="relative h-[60vh] min-h-[400px] overflow-hidden">
        <img src={hero} alt="Atelier" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative h-full flex items-center justify-center text-background text-center px-5">
          <div>
            <p className="tracking-luxe text-xs text-gold mb-4">Maison Videria</p>
            <h1 className="font-serif text-5xl lg:text-7xl">Quietly, since 2019.</h1>
          </div>
        </div>
      </section>

      <section className="max-w-3xl mx-auto px-5 py-24 space-y-8 font-serif text-xl leading-relaxed text-foreground/90">
        <p>Videria began with a single silk gown, sewn in a Florence atelier by a friend of a friend. The seams were perfect. The fabric, almost weightless. We wanted more.</p>
        <p>Today, we work with a small collective of ateliers across Italy and France — twelve, at last count — producing limited runs of pieces we'd want to own ourselves. Nothing more.</p>
        <p className="text-gold">We don't chase trends. We don't shout. We make, and we wait for the right people to find us.</p>
      </section>

      <section className="bg-gradient-dark text-background py-24">
        <div className="max-w-5xl mx-auto px-5 grid md:grid-cols-3 gap-12 text-center">
          {[
            { n: "12", l: "Partner ateliers" },
            { n: "100%", l: "Naturally sourced" },
            { n: "5+", l: "Years of craft" },
          ].map((s) => (
            <div key={s.l}>
              <p className="font-serif text-6xl text-gold">{s.n}</p>
              <p className="tracking-luxe text-xs mt-3 text-background/70">{s.l}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
