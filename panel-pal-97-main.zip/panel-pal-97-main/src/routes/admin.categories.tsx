import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Pencil, Trash2, Plus, Check, X } from "lucide-react";

export const Route = createFileRoute("/admin/categories")({
  component: CategoriesPage,
});

type Cat = { id: string; name: string; slug: string };

const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

function CategoriesPage() {
  const [items, setItems] = useState<Cat[]>([]);
  const [name, setName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");

  const refresh = async () => {
    const { data } = await supabase.from("categories").select("*").order("name");
    setItems((data ?? []) as Cat[]);
  };
  useEffect(() => { refresh(); }, []);

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const { error } = await supabase.from("categories").insert({ name: name.trim(), slug: slugify(name) });
    if (error) return toast.error(error.message);
    setName("");
    toast.success("Category added.");
    refresh();
  };

  const save = async (id: string) => {
    if (!editName.trim()) return;
    const { error } = await supabase.from("categories").update({ name: editName.trim(), slug: slugify(editName) }).eq("id", id);
    if (error) return toast.error(error.message);
    setEditingId(null);
    toast.success("Updated.");
    refresh();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Removed.");
    refresh();
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <p className="tracking-luxe text-xs text-gold mb-2">Taxonomy</p>
        <h1 className="font-serif text-4xl">Categories</h1>
      </div>

      <form onSubmit={add} className="flex gap-2">
        <Input placeholder="New category name" value={name} onChange={(e) => setName(e.target.value)} />
        <Button variant="luxe" type="submit"><Plus className="h-4 w-4 mr-1" /> Add</Button>
      </form>

      <div className="border bg-background divide-y">
        {items.length === 0 && <p className="p-6 text-sm text-muted-foreground">No categories.</p>}
        {items.map((c) => (
          <div key={c.id} className="flex items-center gap-3 p-3">
            {editingId === c.id ? (
              <>
                <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="h-9" autoFocus />
                <button onClick={() => save(c.id)} className="p-2 text-gold" aria-label="Save"><Check className="h-4 w-4" /></button>
                <button onClick={() => setEditingId(null)} className="p-2 text-muted-foreground" aria-label="Cancel"><X className="h-4 w-4" /></button>
              </>
            ) : (
              <>
                <div className="flex-1">
                  <p className="font-medium">{c.name}</p>
                  <p className="text-xs text-muted-foreground">/{c.slug}</p>
                </div>
                <button onClick={() => { setEditingId(c.id); setEditName(c.name); }} className="p-2 hover:text-gold" aria-label="Edit"><Pencil className="h-4 w-4" /></button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <button className="p-2 hover:text-destructive" aria-label="Delete"><Trash2 className="h-4 w-4" /></button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete "{c.name}"?</AlertDialogTitle>
                      <AlertDialogDescription>Products in this category will keep their category label but it may no longer appear in filters.</AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => remove(c.id)}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
