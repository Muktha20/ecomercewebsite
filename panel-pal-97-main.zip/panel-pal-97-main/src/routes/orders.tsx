import { createFileRoute, Link } from "@tanstack/react-router";
import { Package, Truck, CheckCircle2, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/orders")({
  head: () => ({ meta: [{ title: "Orders — Videria" }, { name: "description", content: "Track and manage your orders." }] }),
  component: Orders,
});

const mock = [
  { id: "VID-9F2A1B", date: "May 5, 2026", status: "shipped", total: 1290, items: 1 },
  { id: "VID-7C8E3D", date: "Apr 22, 2026", status: "delivered", total: 480, items: 1 },
  { id: "VID-2B4F8A", date: "Apr 1, 2026", status: "delivered", total: 1840, items: 2 },
];

const steps = ["Placed", "Processing", "Shipped", "Delivered"];

function statusIndex(s: string) {
  return s === "delivered" ? 4 : s === "shipped" ? 3 : s === "processing" ? 2 : 1;
}

function Orders() {
  return (
    <div className="max-w-5xl mx-auto px-5 lg:px-10 py-14">
      <div className="text-center mb-14">
        <p className="tracking-luxe text-xs text-gold mb-3">Account</p>
        <h1 className="font-serif text-5xl">Your Orders</h1>
      </div>
      <div className="space-y-8">
        {mock.map((o) => {
          const idx = statusIndex(o.status);
          return (
            <div key={o.id} className="border bg-card p-7">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-6">
                <div>
                  <p className="font-serif text-2xl">{o.id}</p>
                  <p className="text-xs tracking-luxe text-muted-foreground mt-1">{o.date} · {o.items} item{o.items > 1 ? "s" : ""} · ${o.total}</p>
                </div>
                <Button variant="outlineLuxe" size="sm">View Invoice</Button>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {steps.map((s, i) => {
                  const reached = i < idx;
                  const Icon = i === 0 ? Clock : i === 1 ? Package : i === 2 ? Truck : CheckCircle2;
                  return (
                    <div key={s} className="text-center">
                      <div className={`mx-auto h-10 w-10 rounded-full flex items-center justify-center border ${reached ? "bg-gold border-gold text-gold-foreground" : "border-border text-muted-foreground"}`}>
                        <Icon className="h-4 w-4" />
                      </div>
                      <p className={`mt-2 text-[10px] tracking-luxe ${reached ? "text-foreground" : "text-muted-foreground"}`}>{s}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
      <div className="text-center mt-12">
        <Button variant="luxe" asChild><Link to="/shop">Continue Shopping</Link></Button>
      </div>
    </div>
  );
}
