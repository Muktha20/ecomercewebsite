import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { getProduct, products } from "@/lib/products";
import { useShop, formatPrice } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Heart, Star, Truck, ShieldCheck, RotateCw, Minus, Plus } from "lucide-react";
import { useEffect, useState } from "react";
import { ProductCard } from "@/components/site/ProductCard";
import { toast } from "sonner";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = getProduct(params.id);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.product.name} — Videria` },
          { name: "description", content: loaderData.product.description },
          { property: "og:title", content: `${loaderData.product.name} — Videria` },
          { property: "og:description", content: loaderData.product.description },
          { property: "og:image", content: loaderData.product.image },
        ]
      : [],
  }),
  notFoundComponent: () => (
    <div className="max-w-7xl mx-auto px-5 py-32 text-center">
      <h1 className="font-serif text-5xl">Piece not found</h1>
      <Link to="/shop" className="story-link mt-6 inline-block">Return to the Edit</Link>
    </div>
  ),
  errorComponent: ({ error }) => <div className="p-20 text-center">{error.message}</div>,
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  const add = useShop((s) => s.add);
  const view = useShop((s) => s.view);
  const wishlist = useShop((s) => s.wishlist);
  const toggleWish = useShop((s) => s.toggleWish);
  const recents = useShop((s) => s.recentlyViewed);
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState("M");

  useEffect(() => { view(product.id); }, [product.id, view]);

  const wished = wishlist.includes(product.id);
  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);
  const recentProducts = recents.map((id) => products.find((p) => p.id === id)).filter(Boolean).filter((p) => p!.id !== product.id).slice(0, 4) as typeof products;

  return (
    <div className="max-w-7xl mx-auto px-5 lg:px-10 py-10">
      <nav className="text-xs tracking-luxe text-muted-foreground mb-8">
        <Link to="/" className="hover:text-foreground">Home</Link> / <Link to="/shop" className="hover:text-foreground">Shop</Link> / <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="grid lg:grid-cols-2 gap-12">
        <div className="space-y-3">
          <div className="aspect-[4/5] bg-muted overflow-hidden">
            <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
          </div>
          <div className="grid grid-cols-4 gap-3">
            {[product.image, product.image, product.image, product.image].map((img, i) => (
              <div key={i} className="aspect-square bg-muted overflow-hidden cursor-pointer hover:opacity-80">
                <img src={img} alt="" className="h-full w-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        <div className="lg:sticky lg:top-28 lg:self-start space-y-6">
          {product.badge && <span className="inline-block bg-gold text-gold-foreground px-3 py-1 text-[10px] tracking-luxe">{product.badge}</span>}
          <p className="tracking-luxe text-xs text-muted-foreground">{product.category}</p>
          <h1 className="font-serif text-5xl">{product.name}</h1>
          <div className="flex items-center gap-3 text-sm">
            <div className="flex">{[1, 2, 3, 4, 5].map((i) => <Star key={i} className={`h-4 w-4 ${i <= Math.round(product.rating) ? "fill-gold text-gold" : "text-muted"}`} />)}</div>
            <span className="text-muted-foreground">{product.rating} · {product.reviews} reviews</span>
          </div>
          <p className="text-3xl font-medium">{formatPrice(product.price)}</p>
          <p className="text-muted-foreground leading-relaxed">{product.description}</p>

          <div>
            <p className="tracking-luxe text-xs text-muted-foreground mb-3">Size</p>
            <div className="flex gap-2">
              {["XS", "S", "M", "L", "XL"].map((s) => (
                <button key={s} onClick={() => setSize(s)} className={`h-11 w-11 border text-sm tracking-luxe ${size === s ? "bg-foreground text-background border-foreground" : "border-border hover:border-foreground"}`}>{s}</button>
              ))}
            </div>
          </div>

          <div>
            <p className="tracking-luxe text-xs text-muted-foreground mb-3">Quantity</p>
            <div className="inline-flex items-center border">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="h-11 w-11 hover:bg-muted"><Minus className="h-4 w-4 mx-auto" /></button>
              <span className="w-12 text-center">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="h-11 w-11 hover:bg-muted"><Plus className="h-4 w-4 mx-auto" /></button>
            </div>
          </div>

          <div className="flex gap-2 pt-3">
            <Button variant="luxe" size="xl" className="flex-1" onClick={() => { add(product, qty); toast.success("Added to bag"); }}>Add to Bag</Button>
            <Button variant="outlineLuxe" size="xl" onClick={() => toggleWish(product.id)}>
              <Heart className={`h-4 w-4 ${wished ? "fill-gold text-gold" : ""}`} />
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-6 border-t text-xs tracking-luxe text-muted-foreground">
            <div className="flex flex-col gap-1.5"><Truck className="h-4 w-4 text-gold" /> Free shipping</div>
            <div className="flex flex-col gap-1.5"><RotateCw className="h-4 w-4 text-gold" /> 30-day returns</div>
            <div className="flex flex-col gap-1.5"><ShieldCheck className="h-4 w-4 text-gold" /> Authenticity</div>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-24">
        <h2 className="font-serif text-3xl mb-8">Reviews</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {[
            { n: "Sophia M.", r: 5, t: "Exceeded every expectation. Worth every penny." },
            { n: "James L.", r: 5, t: "Beautifully made. The fit is perfect and the fabric divine." },
            { n: "Aria T.", r: 4, t: "Stunning piece, took some time to ship but worth the wait." },
            { n: "Noor V.", r: 5, t: "I get compliments every time I wear it." },
          ].map((rv, i) => (
            <div key={i} className="border p-6">
              <div className="flex items-center justify-between mb-2">
                <p className="font-medium">{rv.n}</p>
                <div className="flex">{Array.from({ length: rv.r }).map((_, k) => <Star key={k} className="h-3 w-3 fill-gold text-gold" />)}</div>
              </div>
              <p className="text-sm text-muted-foreground">{rv.t}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Customers also bought */}
      <section className="mt-24">
        <h2 className="font-serif text-3xl mb-8">Customers also bought</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {related.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
      </section>

      {recentProducts.length > 0 && (
        <section className="mt-24">
          <h2 className="font-serif text-3xl mb-8">Recently viewed</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
            {recentProducts.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
          </div>
        </section>
      )}
    </div>
  );
}
