import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Product } from "./products";

export function useDbProducts() {
  const [items, setItems] = useState<Product[]>([]);

  const refresh = async () => {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false });
    if (error || !data) return;
    setItems(
      data.map((r) => ({
        id: r.id,
        name: r.name,
        price: Number(r.price),
        image: r.image,
        category: r.category,
        rating: Number(r.rating),
        reviews: r.reviews,
        description: r.description,
        badge: r.badge ?? undefined,
      })),
    );
  };

  useEffect(() => {
    void refresh();
  }, []);

  return { items, refresh };
}
