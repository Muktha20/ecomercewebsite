import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Product } from "./products";

export type CartItem = { product: Product; qty: number };

type ShopState = {
  cart: CartItem[];
  wishlist: string[];
  recentlyViewed: string[];
  cartOpen: boolean;
  coupon: string | null;
  add: (p: Product, qty?: number) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  toggleWish: (id: string) => void;
  view: (id: string) => void;
  openCart: (open: boolean) => void;
  applyCoupon: (code: string) => boolean;
  subtotal: () => number;
  discount: () => number;
  total: () => number;
};

const COUPONS: Record<string, number> = { LUXE10: 0.1, GOLD20: 0.2 };

export const useShop = create<ShopState>()(
  persist(
    (set, get) => ({
      cart: [],
      wishlist: [],
      recentlyViewed: [],
      cartOpen: false,
      coupon: null,
      add: (p, qty = 1) =>
        set((s) => {
          const ex = s.cart.find((c) => c.product.id === p.id);
          return {
            cart: ex
              ? s.cart.map((c) => (c.product.id === p.id ? { ...c, qty: c.qty + qty } : c))
              : [...s.cart, { product: p, qty }],
            cartOpen: true,
          };
        }),
      remove: (id) => set((s) => ({ cart: s.cart.filter((c) => c.product.id !== id) })),
      setQty: (id, qty) =>
        set((s) => ({
          cart: s.cart.map((c) => (c.product.id === id ? { ...c, qty: Math.max(1, qty) } : c)),
        })),
      clear: () => set({ cart: [], coupon: null }),
      toggleWish: (id) =>
        set((s) => ({
          wishlist: s.wishlist.includes(id) ? s.wishlist.filter((x) => x !== id) : [...s.wishlist, id],
        })),
      view: (id) =>
        set((s) => ({
          recentlyViewed: [id, ...s.recentlyViewed.filter((x) => x !== id)].slice(0, 6),
        })),
      openCart: (open) => set({ cartOpen: open }),
      applyCoupon: (code) => {
        const c = code.trim().toUpperCase();
        if (COUPONS[c]) {
          set({ coupon: c });
          return true;
        }
        return false;
      },
      subtotal: () => get().cart.reduce((a, c) => a + c.product.price * c.qty, 0),
      discount: () => {
        const c = get().coupon;
        return c ? get().subtotal() * COUPONS[c] : 0;
      },
      total: () => Math.max(0, get().subtotal() - get().discount()),
    }),
    { name: "videria-shop", partialize: (s) => ({ cart: s.cart, wishlist: s.wishlist, recentlyViewed: s.recentlyViewed, coupon: s.coupon }) }
  )
);

export const formatPrice = (n: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
