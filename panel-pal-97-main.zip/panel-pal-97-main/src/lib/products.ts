import p1 from "@/assets/p1.jpg";
import p2 from "@/assets/p2.jpg";
import p3 from "@/assets/p3.jpg";
import p4 from "@/assets/p4.jpg";
import p5 from "@/assets/p5.jpg";
import p6 from "@/assets/p6.jpg";
import p7 from "@/assets/p7.jpg";
import p8 from "@/assets/p8.jpg";

export type Product = {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  description: string;
  badge?: string;
};

// Prices in INR (₹)
export const products: Product[] = [
  { id: "noir-gown", name: "Noir Silk Gown", price: 107000, image: p1, category: "Apparel", rating: 4.9, reviews: 128, badge: "New", description: "Hand-finished silk-satin gown with sculpted bodice and floor-sweeping train. Cut from heavyweight Italian charmeuse." },
  { id: "aurum-chain", name: "Aurum Layered Chain", price: 39800, image: p2, category: "Jewelry", rating: 4.8, reviews: 96, description: "Two-strand 18k gold-plated chain with secure lobster clasp. Tarnish-resistant finish." },
  { id: "obsidian-tote", name: "Obsidian Leather Tote", price: 76000, image: p3, category: "Bags", rating: 4.7, reviews: 211, badge: "Bestseller", description: "Pebbled calfskin tote with detachable strap and suede-lined interior. Made in Florence." },
  { id: "stiletto-onyx", name: "Onyx Stiletto", price: 57000, image: p4, category: "Footwear", rating: 4.6, reviews: 73, description: "Patent leather pointed pump on a 105mm heel. Cushioned insole." },
  { id: "camel-coat", name: "Camel Wool Coat", price: 129500, image: p5, category: "Apparel", rating: 4.9, reviews: 154, badge: "Limited", description: "Oversized double-breasted coat in pure virgin wool with horn buttons." },
  { id: "midas-watch", name: "Midas Chronograph", price: 186000, image: p6, category: "Accessories", rating: 5.0, reviews: 41, description: "Gold-tone chronograph on hand-stitched alligator strap. Sapphire crystal." },
  { id: "noir-shades", name: "Noir Round Shades", price: 26500, image: p7, category: "Accessories", rating: 4.5, reviews: 88, description: "Acetate frame with gold metal core. UV400 protection." },
  { id: "layanel-parfum", name: "Layanel Eau de Parfum", price: 14900, image: p8, category: "Beauty", rating: 4.8, reviews: 302, description: "Amber, oud and bergamot. 100ml flacon." },
];

export const categories = ["All", "Apparel", "Bags", "Jewelry", "Footwear", "Accessories", "Beauty"] as const;

export const getProduct = (id: string) => products.find(p => p.id === id);
