import { Link } from "@tanstack/react-router";
import { Instagram, Twitter, Youtube } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Footer() {
  return (
    <footer className="bg-gradient-dark text-background mt-32">
      <div className="max-w-7xl mx-auto px-5 lg:px-10 py-20 grid gap-12 lg:grid-cols-4">
        <div className="lg:col-span-2 space-y-5">
          <div className="font-serif text-3xl">VIDERIA<span className="text-gold">.</span></div>
          <p className="text-sm text-background/60 max-w-sm leading-relaxed">
            Quietly crafted luxury. Considered pieces, made in small ateliers across Italy and France.
          </p>
          <form className="flex max-w-sm gap-2" onSubmit={(e) => e.preventDefault()}>
            <Input
              type="email"
              required
              placeholder="Your email"
              className="bg-transparent border-background/30 text-background placeholder:text-background/50"
            />
            <Button variant="luxe" type="submit">Subscribe</Button>
          </form>
        </div>

        <div className="space-y-3 text-sm">
          <h4 className="tracking-luxe text-xs text-gold mb-4">Maison</h4>
          <Link to="/about" className="block text-background/70 hover:text-gold transition-colors">Our Story</Link>
          <Link to="/contact" className="block text-background/70 hover:text-gold transition-colors">Contact</Link>
          <Link to="/shop" className="block text-background/70 hover:text-gold transition-colors">Shop All</Link>
          <Link to="/orders" className="block text-background/70 hover:text-gold transition-colors">Order Tracking</Link>
        </div>

        <div className="space-y-3 text-sm">
          <h4 className="tracking-luxe text-xs text-gold mb-4">Care</h4>
          <span className="block text-background/70">Shipping & Returns</span>
          <span className="block text-background/70">Privacy Policy</span>
          <span className="block text-background/70">Terms of Service</span>
          <div className="flex gap-3 pt-3">
            <Instagram className="h-4 w-4 text-background/70 hover:text-gold transition-colors cursor-pointer" />
            <Twitter className="h-4 w-4 text-background/70 hover:text-gold transition-colors cursor-pointer" />
            <Youtube className="h-4 w-4 text-background/70 hover:text-gold transition-colors cursor-pointer" />
          </div>
        </div>
      </div>
      <div className="border-t border-background/10">
        <div className="max-w-7xl mx-auto px-5 lg:px-10 py-6 text-xs text-background/40 flex flex-col sm:flex-row justify-between gap-2">
          <span>© {new Date().getFullYear()} Videria Maison. All rights reserved.</span>
          <span>Crafted with care.</span>
        </div>
      </div>
    </footer>
  );
}
