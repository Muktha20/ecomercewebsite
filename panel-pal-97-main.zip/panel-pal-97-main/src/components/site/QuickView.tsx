import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Product } from "@/lib/products";
import { formatPrice, useShop } from "@/lib/store";
import { Star } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function QuickView({ product, open, onOpenChange }: { product: Product; open: boolean; onOpenChange: (o: boolean) => void }) {
  const add = useShop((s) => s.add);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden">
        <div className="grid md:grid-cols-2">
          <div className="aspect-square bg-muted">
            <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
          </div>
          <div className="p-8 flex flex-col gap-4">
            <p className="text-[10px] tracking-luxe text-muted-foreground">{product.category}</p>
            <h2 className="font-serif text-3xl">{product.name}</h2>
            <div className="flex items-center gap-2 text-sm">
              <Star className="h-4 w-4 fill-gold text-gold" />
              <span>{product.rating}</span>
              <span className="text-muted-foreground">({product.reviews} reviews)</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{product.description}</p>
            <div className="text-2xl font-medium">{formatPrice(product.price)}</div>
            <div className="flex gap-2 mt-auto pt-4">
              <Button variant="luxe" className="flex-1" onClick={() => { add(product); onOpenChange(false); }}>Add to Bag</Button>
              <Link to="/product/$id" params={{ id: product.id }} onClick={() => onOpenChange(false)}>
                <Button variant="outline">Details</Button>
              </Link>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
