import { Link } from "@tanstack/react-router";
import { Heart, ShoppingBag, Eye, Star } from "lucide-react";
import type { Product } from "@/lib/products";
import { useShop, formatPrice } from "@/lib/store";
import { useState } from "react";
import { QuickView } from "./QuickView";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const add = useShop((s) => s.add);
  const wishlist = useShop((s) => s.wishlist);
  const toggleWish = useShop((s) => s.toggleWish);
  const wished = wishlist.includes(product.id);
  const [quick, setQuick] = useState(false);

  return (
    <>
      <div
        className="group relative animate-fade-up"
        style={{ animationDelay: `${Math.min(index, 8) * 60}ms` }}
      >
        <div className="relative aspect-[4/5] overflow-hidden bg-muted">
          <Link to="/product/$id" params={{ id: product.id }}>
            <img
              src={product.image}
              alt={product.name}
              loading="lazy"
              width={800}
              height={1000}
              className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-110"
            />
          </Link>

          {product.badge && (
            <span className="absolute top-3 left-3 bg-background/90 backdrop-blur px-3 py-1 text-[10px] tracking-luxe">
              {product.badge}
            </span>
          )}

          <button
            onClick={(e) => { e.preventDefault(); toggleWish(product.id); }}
            className="absolute top-3 right-3 h-9 w-9 rounded-full glass flex items-center justify-center hover:scale-110 transition-transform"
            aria-label="Wishlist"
          >
            <Heart className={`h-4 w-4 ${wished ? "fill-gold text-gold" : ""}`} />
          </button>

          <div className="absolute inset-x-3 bottom-3 flex gap-2 opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
            <button
              onClick={() => add(product)}
              className="flex-1 bg-foreground text-background py-3 text-[11px] tracking-luxe flex items-center justify-center gap-2 hover:bg-gold hover:text-gold-foreground transition-colors"
            >
              <ShoppingBag className="h-3.5 w-3.5" /> Add
            </button>
            <button
              onClick={() => setQuick(true)}
              className="h-11 w-11 bg-background flex items-center justify-center hover:bg-gold transition-colors"
              aria-label="Quick view"
            >
              <Eye className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="pt-4 space-y-1">
          <p className="text-[10px] tracking-luxe text-muted-foreground">{product.category}</p>
          <Link to="/product/$id" params={{ id: product.id }} className="block font-serif text-lg hover:text-gold transition-colors">
            {product.name}
          </Link>
          <div className="flex items-center justify-between pt-1">
            <span className="font-medium">{formatPrice(product.price)}</span>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Star className="h-3 w-3 fill-gold text-gold" /> {product.rating}
            </span>
          </div>
        </div>
      </div>
      <QuickView product={product} open={quick} onOpenChange={setQuick} />
    </>
  );
}
