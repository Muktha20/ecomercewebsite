import { Link, useRouterState } from "@tanstack/react-router";
import { Heart, Search, ShoppingBag, User, Menu, X, Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";
import { useShop } from "@/lib/store";
import { Button } from "@/components/ui/button";

const links = [
  { to: "/", label: "Home" },
  { to: "/shop", label: "Shop" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Help" },
  { to: "/admin", label: "Admin" },
];

export function Header() {
  const cart = useShop((s) => s.cart);
  const wishlist = useShop((s) => s.wishlist);
  const openCart = useShop((s) => s.openCart);
  const path = useRouterState({ select: (r) => r.location.pathname });
  const [scrolled, setScrolled] = useState(false);
  const [mobile, setMobile] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const stored = localStorage.getItem("theme");
    const isDark = stored === "dark";
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  const cartCount = cart.reduce((a, c) => a + c.qty, 0);

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "glass border-b border-border/60" : "bg-transparent"}`}>
      <div className="max-w-7xl mx-auto px-5 lg:px-10 h-16 lg:h-20 flex items-center justify-between gap-6">
        <button onClick={() => setMobile(true)} className="lg:hidden p-2 -ml-2" aria-label="Menu">
          <Menu className="h-5 w-5" />
        </button>

        <Link to="/" className="font-serif text-2xl lg:text-3xl tracking-tight">
          VIDERIA<span className="text-gold">.</span>
        </Link>

        <nav className="hidden lg:flex items-center gap-10 text-xs tracking-luxe">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={`story-link ${path === l.to ? "text-gold" : "text-foreground/80 hover:text-foreground"}`}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" aria-label="Search"><Search className="h-4 w-4" /></Button>
          <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle theme">
            {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          <Link to="/wishlist" className="relative">
            <Button variant="ghost" size="icon" aria-label="Wishlist">
              <Heart className="h-4 w-4" />
              {wishlist.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-gold text-gold-foreground text-[10px] h-4 min-w-4 px-1 rounded-full flex items-center justify-center font-medium">{wishlist.length}</span>
              )}
            </Button>
          </Link>
          <Button variant="ghost" size="icon" onClick={() => openCart(true)} aria-label="Cart" className="relative">
            <ShoppingBag className="h-4 w-4" />
            {cartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 bg-gold text-gold-foreground text-[10px] h-4 min-w-4 px-1 rounded-full flex items-center justify-center font-medium">{cartCount}</span>
            )}
          </Button>
          <Link to="/account" className="hidden lg:block">
            <Button variant="ghost" size="icon" aria-label="Account"><User className="h-4 w-4" /></Button>
          </Link>
        </div>
      </div>

      {mobile && (
        <div className="fixed inset-0 z-50 bg-background animate-fade-up lg:hidden">
          <div className="flex items-center justify-between p-5 border-b">
            <span className="font-serif text-2xl">VIDERIA<span className="text-gold">.</span></span>
            <button onClick={() => setMobile(false)} aria-label="Close"><X className="h-5 w-5" /></button>
          </div>
          <nav className="flex flex-col p-8 gap-6 font-serif text-3xl">
            {links.map((l) => (
              <Link key={l.to} to={l.to} onClick={() => setMobile(false)} className="hover:text-gold transition-colors">
                {l.label}
              </Link>
            ))}
            <Link to="/account" onClick={() => setMobile(false)} className="hover:text-gold transition-colors">Account</Link>
            <Link to="/orders" onClick={() => setMobile(false)} className="hover:text-gold transition-colors">Orders</Link>
          </nav>
        </div>
      )}
    </header>
  );
}
