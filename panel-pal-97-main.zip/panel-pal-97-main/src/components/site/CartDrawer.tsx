import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { useShop, formatPrice } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2 } from "lucide-react";
import { Link } from "@tanstack/react-router";

export function CartDrawer() {
  const { cart, cartOpen, openCart, setQty, remove, subtotal } = useShop();

  return (
    <Sheet open={cartOpen} onOpenChange={openCart}>
      <SheetContent className="w-full sm:max-w-md flex flex-col p-0 gap-0">
        <SheetHeader className="px-6 py-5 border-b">
          <SheetTitle className="font-serif text-2xl">Your Bag <span className="text-muted-foreground text-base">({cart.length})</span></SheetTitle>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 p-8 text-center">
            <p className="font-serif text-2xl">Your bag awaits.</p>
            <p className="text-sm text-muted-foreground">Discover pieces worth keeping.</p>
            <Button variant="luxe" onClick={() => openCart(false)} asChild>
              <Link to="/shop">Explore the Edit</Link>
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
              {cart.map((item) => (
                <div key={item.product.id} className="flex gap-4">
                  <div className="h-24 w-20 bg-muted overflow-hidden flex-shrink-0">
                    <img src={item.product.image} alt={item.product.name} className="h-full w-full object-cover" />
                  </div>
                  <div className="flex-1 flex flex-col">
                    <div className="flex justify-between gap-2">
                      <div>
                        <p className="text-[10px] tracking-luxe text-muted-foreground">{item.product.category}</p>
                        <p className="font-serif text-base leading-tight">{item.product.name}</p>
                      </div>
                      <button onClick={() => remove(item.product.id)} className="text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-center justify-between">
                      <div className="flex items-center border">
                        <button onClick={() => setQty(item.product.id, item.qty - 1)} className="px-2 py-1 hover:bg-muted"><Minus className="h-3 w-3" /></button>
                        <span className="px-3 text-sm">{item.qty}</span>
                        <button onClick={() => setQty(item.product.id, item.qty + 1)} className="px-2 py-1 hover:bg-muted"><Plus className="h-3 w-3" /></button>
                      </div>
                      <span className="font-medium">{formatPrice(item.product.price * item.qty)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t px-6 py-5 space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-medium">{formatPrice(subtotal())}</span>
              </div>
              <p className="text-xs text-muted-foreground">Shipping and taxes calculated at checkout.</p>
              <Button variant="luxe" className="w-full" onClick={() => openCart(false)} asChild>
                <Link to="/checkout">Checkout</Link>
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
