
-- Roles
create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;
revoke execute on function public.has_role(uuid, app_role) from anon, authenticated, public;

create policy "users view own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);
create policy "admins view all roles" on public.user_roles for select to authenticated using (public.has_role(auth.uid(), 'admin'));

-- Products
create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price numeric not null,
  image text not null,
  category text not null,
  description text not null default '',
  rating numeric not null default 4.5,
  reviews int not null default 0,
  badge text,
  stock integer not null default 100,
  brand text,
  offer_price numeric,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.products enable row level security;
create policy "anyone can view products" on public.products for select using (true);
create policy "admins insert products" on public.products for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "admins update products" on public.products for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "admins delete products" on public.products for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

-- Categories
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  created_at timestamptz not null default now()
);
alter table public.categories enable row level security;
create policy "anyone view categories" on public.categories for select using (true);
create policy "admins insert categories" on public.categories for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "admins update categories" on public.categories for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "admins delete categories" on public.categories for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

insert into public.categories (name, slug) values
  ('Apparel','apparel'),('Bags','bags'),('Jewelry','jewelry'),
  ('Footwear','footwear'),('Accessories','accessories'),('Beauty','beauty')
on conflict (name) do nothing;

-- Profiles
create table public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique,
  email text,
  display_name text,
  blocked boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "users view own profile" on public.profiles for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "admins delete profiles" on public.profiles for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "users insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = user_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (user_id, email, display_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', new.email))
  on conflict (user_id) do nothing;
  return new;
end;
$$;
revoke execute on function public.handle_new_user() from public, anon, authenticated;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Auto-grant admin
create or replace function public.grant_admin_for_muktha()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.email = 'mukthamuktha662@gmail.com' then
    insert into public.user_roles (user_id, role)
    values (new.id, 'admin'::app_role)
    on conflict (user_id, role) do nothing;
  end if;
  return new;
end;
$$;
revoke execute on function public.grant_admin_for_muktha() from public, anon, authenticated;
drop trigger if exists on_auth_user_created_grant_admin on auth.users;
create trigger on_auth_user_created_grant_admin
  after insert on auth.users
  for each row execute function public.grant_admin_for_muktha();

-- Backfill if user already exists
insert into public.user_roles (user_id, role)
select id, 'admin'::app_role from auth.users where email = 'mukthamuktha662@gmail.com'
on conflict (user_id, role) do nothing;

-- Orders
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  email text,
  items jsonb not null default '[]'::jsonb,
  subtotal numeric not null default 0,
  total numeric not null default 0,
  status text not null default 'pending',
  shipping_address jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.orders enable row level security;
create policy "users view own orders" on public.orders for select to authenticated using (auth.uid() = user_id or public.has_role(auth.uid(), 'admin'));
create policy "users create own orders" on public.orders for insert to authenticated with check (auth.uid() = user_id);
create policy "admins update orders" on public.orders for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "admins delete orders" on public.orders for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
