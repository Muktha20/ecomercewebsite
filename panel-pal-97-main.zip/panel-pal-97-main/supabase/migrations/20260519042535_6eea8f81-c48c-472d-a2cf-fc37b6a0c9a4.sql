
REVOKE EXECUTE ON FUNCTION public.grant_admin_for_muktha() FROM PUBLIC, anon, authenticated;
