
create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "users view own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);
create policy "admins view all roles" on public.user_roles for select to authenticated using (public.has_role(auth.uid(), 'admin'));

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  price numeric not null,
  image text not null,
  category text not null,
  description text not null default '',
  rating numeric not null default 4.5,
  reviews int not null default 0,
  badge text,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

create policy "anyone can view products" on public.products for select using (true);
create policy "admins insert products" on public.products for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "admins update products" on public.products for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "admins delete products" on public.products for delete to authenticated using (public.has_role(auth.uid(), 'admin'));
